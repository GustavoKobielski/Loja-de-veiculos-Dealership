
# Loja de veiculos com DataBase

### Sobre

Projeto de loja de veiculos usando python com db (MySql Workbench)


### Funcionamento

Quando inicia-se o código, ele irá pedir se você quer entrar como cliente ou funcionário, caso escolha como funcionário ele irá pedir seu cpf, senha, caso esteja correto, ele irá retornar Bem vindo nome (nome cadastrado com esse cpf), e irá aparecer as opções para escolha de adicionar veiculo, remover veiculo, listar veiculo, retornar ao inicio.

### Uso:

Python : mysql-connector
Sql : MySql Workbench



# Dealership using DataBase

### About

Vehicle store project using python and db (MySql Workbench)


### Operation

When the code starts, it will ask if you want to enter as a customer or employee, if you choose as an employee it will ask for your CPF, password, if it is correct, it will return Welcome name (name registered with this CPF), and The options will appear to choose to add vehicle, remove vehicle, list vehicle, return to the beginning.

### Usage

Python : mysql-connector
Sql : MySql Workbench